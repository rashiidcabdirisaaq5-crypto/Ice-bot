import os, hmac
from functools import wraps
from flask import Flask, request, redirect, url_for, session, flash, render_template_string

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "CHANGE_THIS_SECRET_BEFORE_DEPLOY")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")

PAGE_STYLE = """
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 20% 10%,#073b70 0,#06152d 38%,#020817 100%);color:#f3f8ff;font-family:Arial,sans-serif}
.wrap{width:min(920px,94%);margin:28px auto}.hero,.card{background:#071a35eF;border:1px solid #087fd0;border-radius:22px;padding:25px;box-shadow:0 0 28px #007bff25}
h1{font-size:clamp(38px,8vw,64px);margin:8px 0}h1 span,.cyan{color:#13cfff}.eyebrow{letter-spacing:3px;color:#65dfff;font-size:12px}
.muted{color:#9bb5d2;line-height:1.5}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:center}
input{width:100%;padding:15px;margin:8px 0 15px;border-radius:12px;border:1px solid #2679b9;background:#041127;color:white;font-size:16px}
label{color:#c5ddf5}button,.btn{display:inline-block;padding:14px 18px;border:0;border-radius:12px;background:linear-gradient(90deg,#06bde9,#075cff);color:white;font-weight:bold;text-decoration:none;font-size:16px}
.error{color:#ff9ba8}.notice{padding:14px;background:#352c12;border:1px solid #a98224;border-radius:12px;color:#ffe4a1;line-height:1.5}
.stats{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}.stat{flex:1;min-width:130px;background:#041127;padding:14px;border-radius:12px}.pill{display:inline-block;background:#153d63;color:#6fe3ff;border-radius:30px;padding:8px 12px;font-size:12px}
.chart{height:125px;border-radius:14px;background:repeating-linear-gradient(0deg,transparent 0 30px,#17416a 31px),repeating-linear-gradient(90deg,transparent 0 48px,#17416a 49px);display:flex;align-items:center;gap:12px;padding:15px;margin-top:18px}
.candle{width:12px;height:45px;background:#08d98b;box-shadow:0 -12px 0 -5px #08d98b,0 12px 0 -5px #08d98b}.candle.red{height:30px;background:#ff536b;box-shadow:0 -10px 0 -5px #ff536b,0 10px 0 -5px #ff536b}
.signal{padding:16px 0;border-bottom:1px solid #173858}footer{text-align:center;color:#7894b4;padding:22px}
@media(max-width:650px){.grid{grid-template-columns:1fr}.wrap{margin:16px auto}.hero,.card{padding:19px}}
"""

LOGIN = """
<!doctype html><html lang="so"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ICE BOT Login</title><style>{{style}}</style></head>
<body><main class="wrap grid"><section class="hero"><div class="cyan" style="font-size:48px">❄</div><div class="eyebrow">QUOTEX OTC SIGNALS</div><h1>ICE <span>BOT</span></h1><p class="muted">Candle-reading dashboard · Private access</p><div class="chart">{% for i in range(12) %}<i class="candle {{'red' if i in [2,5,8] else ''}}"></i>{% endfor %}</div><p class="muted">Bullish Engulfing · Hammer · 1-minute candles</p></section>
<section class="card"><div class="cyan" style="font-size:40px">◈</div><h2>Ku soo dhowow ICE BOT</h2><p class="muted">Gelitaan gaar ah oo Admin-ku oggolaaday</p>{% with messages=get_flashed_messages() %}{% if messages %}<p class="error">{{messages[0]}}</p>{% endif %}{% endwith %}
<form method="post"><label>Username</label><input name="username" autocomplete="username" placeholder="Geli username" required><label>Password</label><input name="password" type="password" autocomplete="current-password" placeholder="Geli password" required><button type="submit" style="width:100%">LOGIN →</button></form><p class="muted">Authorized users only</p></section></main></body></html>
"""

DASHBOARD = """
<!doctype html><html lang="so"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ICE BOT Dashboard</title><style>{{style}}</style></head>
<body><main class="wrap"><header style="display:flex;justify-content:space-between;align-items:center;gap:12px"><div><div class="eyebrow">PRIVATE OTC SIGNALS</div><h1>ICE <span>BOT</span></h1></div><a class="btn" href="/logout">Logout</a></header>
<section class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><p class="muted">Ku soo dhowow, {{username}}</p><h2>Signal Dashboard</h2></div><span class="pill">DEMO MODE</span></div>
<div class="notice">MUHIIM: Tani waa dashboard tijaabo ah. OTCharts API iyo Telegram weli lama xirin. Ha u isticmaalin signal-kan trading lacag dhab ah.</div>
<div class="stats"><div class="stat"><small>MARKET</small><h3>Quotex OTC</h3></div><div class="stat"><small>TIMEFRAME</small><h3>1 Minute</h3></div><div class="stat"><small>EXPIRY TEST</small><h3>2 Minutes</h3></div></div>
<div class="chart">{% for i in range(16) %}<i class="candle {{'red' if i in [3,6,9,12] else ''}}"></i>{% endfor %}</div></section>
<section class="card" style="margin-top:18px"><h2>Recent Signals</h2><div class="signal"><b class="cyan">WAITING FOR CANDLE DATA</b><p class="muted">Bullish Engulfing / Hammer</p><span class="pill">WAIT</span></div><p class="muted">Signal dhab ah lama soo saarayo ilaa xogta candles-ka si sax ah loo xiro loona tijaabiyo.</p></section>
<footer>ICE BOT · No profit is guaranteed.</footer></main></body></html>
"""

@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u=request.form.get("username","").strip()
        p=request.form.get("password","")
        if ADMIN_USERNAME and ADMIN_PASSWORD and hmac.compare_digest(u, ADMIN_USERNAME) and hmac.compare_digest(p, ADMIN_PASSWORD):
            session["logged_in"]=True
            session["username"]=u
            return redirect(url_for("dashboard"))
        flash("Username ama password waa khalad. Hubi xogta Render.")
    return render_template_string(LOGIN, style=PAGE_STYLE)

def required(fn):
    @wraps(fn)
    def inner(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return inner

@app.route("/dashboard")
@required
def dashboard():
    return render_template_string(DASHBOARD, style=PAGE_STYLE, username=session.get("username"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/health")
def health():
    return {"status":"ok","mode":"demo - live candle data not connected"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)))
