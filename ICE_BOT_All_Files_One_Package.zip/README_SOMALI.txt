ICE BOT - DHAMMAAN FAYLASHA HALKAN

Faylasha ZIP-kan:
- app.py (login + dashboard + naqshadda; hal fayl)
- requirements.txt
- Procfile
- render.yaml

Sida GitHub loogu shubo Android:
1. ZIP-kan Extract ka samee telefoonka.
2. GitHub repository-ga Ice-bot ka fur browser-ka.
3. Riix Add file > Upload files.
4. Dooro afarta fayl ee kore (ha dooran ZIP-ka).
5. Riix Commit changes.

Render:
Build command: pip install -r requirements.txt
Start command: gunicorn app:app

Environment Variables gudaha Render:
ADMIN_USERNAME = username-ka Admin-ka aad rabto
ADMIN_PASSWORD = password adag oo cusub
SECRET_KEY = xarfo dheer oo qarsoodi ah

MUHIIM:
- Kani waa demo login/dashboard; OTCharts API, Telegram iyo multi-user admin weli kuma xirna.
- Ha gelin password, API key ama Quotex login gudaha GitHub.
- Siraha ku qor Render Environment Variables oo keliya.
- Ha u adeegsan demo-kan trading lacag dhab ah.
